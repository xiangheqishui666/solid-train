/****************************************************************************
** Meta object code from reading C++ file 'masterview.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.11)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Lab3/masterview.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'masterview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.11. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MasterView_t {
    QByteArrayData data[14];
    char stringdata0[195];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MasterView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MasterView_t qt_meta_stringdata_MasterView = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MasterView"
QT_MOC_LITERAL(1, 11, 11), // "goLoginView"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 12), // "goWelcomView"
QT_MOC_LITERAL(4, 37, 12), // "goDoctorView"
QT_MOC_LITERAL(5, 50, 16), // "goDepartmentView"
QT_MOC_LITERAL(6, 67, 17), // "goPatientEditView"
QT_MOC_LITERAL(7, 85, 5), // "rowNo"
QT_MOC_LITERAL(8, 91, 13), // "goPatientView"
QT_MOC_LITERAL(9, 105, 14), // "goPreviousView"
QT_MOC_LITERAL(10, 120, 17), // "on_btBack_clicked"
QT_MOC_LITERAL(11, 138, 31), // "on_stackedWidget_currentChanged"
QT_MOC_LITERAL(12, 170, 4), // "arg1"
QT_MOC_LITERAL(13, 175, 19) // "on_btLogout_clicked"

    },
    "MasterView\0goLoginView\0\0goWelcomView\0"
    "goDoctorView\0goDepartmentView\0"
    "goPatientEditView\0rowNo\0goPatientView\0"
    "goPreviousView\0on_btBack_clicked\0"
    "on_stackedWidget_currentChanged\0arg1\0"
    "on_btLogout_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MasterView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x0a /* Public */,
       3,    0,   65,    2, 0x0a /* Public */,
       4,    0,   66,    2, 0x0a /* Public */,
       5,    0,   67,    2, 0x0a /* Public */,
       6,    1,   68,    2, 0x0a /* Public */,
       8,    0,   71,    2, 0x0a /* Public */,
       9,    0,   72,    2, 0x0a /* Public */,
      10,    0,   73,    2, 0x08 /* Private */,
      11,    1,   74,    2, 0x08 /* Private */,
      13,    0,   77,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,

       0        // eod
};

void MasterView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MasterView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->goLoginView(); break;
        case 1: _t->goWelcomView(); break;
        case 2: _t->goDoctorView(); break;
        case 3: _t->goDepartmentView(); break;
        case 4: _t->goPatientEditView((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->goPatientView(); break;
        case 6: _t->goPreviousView(); break;
        case 7: _t->on_btBack_clicked(); break;
        case 8: _t->on_stackedWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_btLogout_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MasterView::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_MasterView.data,
    qt_meta_data_MasterView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MasterView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MasterView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MasterView.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int MasterView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
