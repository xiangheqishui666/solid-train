bool IDatabase::initDepartmentModel()
{
    if (m_depTabModel) {
        return true;
    }

    if (!m_database.isOpen()) {
        qCritical() << "[Dep模型错误] 数据库未打开，无法初始化科室模型";
        return false;
    }

    m_depTabModel = new QSqlTableModel(this, m_database);
    m_depTabModel->setTable("department"); // 假设表名为 department
    m_depTabModel->setEditStrategy(QSqlTableModel::OnManualSubmit);

    // 假设按名称排序
    int nameIdx = m_depTabModel->fieldIndex("name");
    if (nameIdx != -1) {
        m_depTabModel->setSort(nameIdx, Qt::AscendingOrder);
    }

    if (!m_depTabModel->select()) {
        qCritical() << "[Dep模型错误] 加载department表失败：" << m_depTabModel->lastError().text();
        delete m_depTabModel;
        m_depTabModel = nullptr;
        return false;
    }

    m_theDepSelection = new QItemSelectionModel(m_depTabModel);
    qInfo() << "[Dep模型成功] 加载department表，共" << m_depTabModel->rowCount() << "行";
    return true;
}

int IDatabase::addNewDepartment()
{
    if (!m_depTabModel || !m_database.isOpen()) {
        qCritical() << "[Dep新增错误] 模型/数据库未初始化";
        return -1;
    }

    int newRow = m_depTabModel->rowCount();
    if (!m_depTabModel->insertRow(newRow)) {
        qCritical() << "[Dep新增错误] 插入行失败：" << m_depTabModel->lastError().text();
        return -1;
    }

    // 获取字段索引
    int idColIndex = m_depTabModel->fieldIndex("ID");
    int createTimeColIndex = m_depTabModel->fieldIndex("CREATEDTIMESTAMP");
    int nameColIndex = m_depTabModel->fieldIndex("NAME");

    if (idColIndex == -1) {
        qCritical() << "[Dep新增错误] 未找到ID字段！请检查数据库表结构";
        m_depTabModel->removeRow(newRow); // 回滚插入
        return -1;
    }

    // 生成 UUID
    QString uniqueID = QUuid::createUuid().toString(QUuid::WithoutBraces);
    m_depTabModel->setData(m_depTabModel->index(newRow, idColIndex), uniqueID);

    // 设置默认值
    if (createTimeColIndex != -1)
        m_depTabModel->setData(m_depTabModel->index(newRow, createTimeColIndex),
                               QDateTime::currentDateTime().toString("yyyy-MM-dd"));
    if (nameColIndex != -1)
        m_depTabModel->setData(m_depTabModel->index(newRow, nameColIndex), "新建科室");

    qInfo() << "[Dep新增成功] 内存中新增行，索引：" << newRow << "，ID：" << uniqueID;
    return newRow;
}

bool IDatabase::searchDepartment(QString filter)
{
    if (!m_depTabModel) return false;
    m_depTabModel->setFilter(filter);
    bool ok = m_depTabModel->select();
    if (!ok) {
        qCritical() << "[Dep搜索错误] 筛选失败：" << m_depTabModel->lastError().text();
    }
    return ok;
}

bool IDatabase::deleteCurrentDepartment()
{
    if (!m_depTabModel || !m_theDepSelection || !m_database.isOpen()) {
        qCritical() << "[Dep删除错误] 模型/选择模型/数据库未初始化";
        return false;
    }

    QModelIndex curIdx = m_theDepSelection->currentIndex();
    if (!curIdx.isValid()) {
        qWarning() << "[Dep删除错误] 未选中任何行";
        return false;
    }

    if (!m_depTabModel->removeRow(curIdx.row())) {
        qCritical() << "[Dep删除错误] 移除行失败：" << m_depTabModel->lastError().text();
        return false;
    }

    bool ok = m_depTabModel->submitAll();
    if (ok) {
        m_depTabModel->select();
        qInfo() << "[Dep删除成功] 已删除行：" << curIdx.row();
    } else {
        qCritical() << "[Dep删除失败] 提交失败：" << m_depTabModel->lastError().text();
        m_depTabModel->revertAll();
    }
    return ok;
}

bool IDatabase::submitDepartmentEdit()
{
    if (!m_depTabModel || !m_database.isOpen()) return false;

    // 简单校验 ID
    int idColIndex = m_depTabModel->fieldIndex("ID");
    for (int i = 0; i < m_depTabModel->rowCount(); i++) {
        QVariant idValue = m_depTabModel->data(m_depTabModel->index(i, idColIndex));
        if (idValue.isNull() || idValue.toString().trimmed().isEmpty()) {
            qCritical() << "[Dep提交错误] 第" << i << "行ID为空，禁止提交";
            return false;
        }
    }

    bool ok = m_depTabModel->submitAll();
    if (ok) {
        m_depTabModel->select();
        qInfo() << "[Dep提交成功]";
    } else {
        qCritical() << "[Dep提交失败] " << m_depTabModel->lastError().text();
        m_depTabModel->revertAll();
    }
    return ok;
}

void IDatabase::revertDepartmentEdit()
{
    if (m_depTabModel) {
        m_depTabModel->revertAll();
        qInfo() << "[Dep回滚成功]";
    }
}
